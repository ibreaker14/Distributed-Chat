var searchData=
[
  ['mutex',['mutex',['../class_chat.html#a2d05c5a786842fdaabf5d54c5b34f1de',1,'Chat']]],
  ['myalias',['myAlias',['../class_chat.html#a35d411ee8dc3a5b258f9196b45ac4cc9',1,'Chat']]],
  ['myport',['myPort',['../class_chat.html#adf3015afad6879dd1b21a181ce21b16b',1,'Chat']]]
];
