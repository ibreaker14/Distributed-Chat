var searchData=
[
  ['localhost',['localhost',['../class_chat.html#aef192c9fcd2a24c9a684f1110afd7de4',1,'Chat']]]
];
