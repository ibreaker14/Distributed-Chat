var searchData=
[
  ['clntsock',['clntSock',['../class_chat_1_1_server.html#ac1ee7f354d453923201032c2935cff01',1,'Chat::Server']]]
];
