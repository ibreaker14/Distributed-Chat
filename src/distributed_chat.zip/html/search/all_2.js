var searchData=
[
  ['joined',['joined',['../class_chat.html#aabecdb7e794abb969b3a141365d372fe',1,'Chat']]],
  ['jsonmessage',['JSONMessage',['../class_chat.html#aedb8547771734d3275f8acfe106ba332',1,'Chat']]]
];
