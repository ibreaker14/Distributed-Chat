var searchData=
[
  ['portpredecessor',['portPredecessor',['../class_chat.html#a171c1e8e84a991d86eea4603ec2242d6',1,'Chat']]],
  ['portsuccessor',['portSuccessor',['../class_chat.html#a318592ab88caa043fa38ae3a5b2222ad',1,'Chat']]]
];
