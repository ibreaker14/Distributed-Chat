var searchData=
[
  ['run',['run',['../class_chat_1_1_server.html#a90f3bd24ca99aa3ebf510d1f41b245c3',1,'Chat.Server.run()'],['../class_chat_1_1_client.html#af929f8bd324136e11afe64c92fa1cac3',1,'Chat.Client.run()']]]
];
