var searchData=
[
  ['server',['Server',['../class_chat_1_1_server.html#a3d7288f69967e91d0f3dbfb148f4270b',1,'Chat::Server']]]
];
