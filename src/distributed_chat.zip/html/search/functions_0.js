var searchData=
[
  ['chat',['Chat',['../class_chat.html#a2e9b5fbe06ab99eee05f0fc6af6dc887',1,'Chat']]],
  ['client',['Client',['../class_chat_1_1_client.html#a4b7e710445daa791b57d2345ebc97b1e',1,'Chat::Client']]]
];
