var searchData=
[
  ['ois',['ois',['../class_chat_1_1_client.html#ac2c94245dead3d3b4da321672ae38197',1,'Chat::Client']]],
  ['oos',['oos',['../class_chat_1_1_client.html#a7eb6aefa20159a1de2a4cbe2872087bd',1,'Chat::Client']]]
];
