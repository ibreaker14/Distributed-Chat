var searchData=
[
  ['chat',['Chat',['../class_chat.html',1,'Chat'],['../class_chat.html#a2e9b5fbe06ab99eee05f0fc6af6dc887',1,'Chat.Chat()']]],
  ['client',['Client',['../class_chat_1_1_client.html',1,'Chat.Client'],['../class_chat_1_1_client.html#a4b7e710445daa791b57d2345ebc97b1e',1,'Chat.Client.Client()']]],
  ['clntsock',['clntSock',['../class_chat_1_1_server.html#ac1ee7f354d453923201032c2935cff01',1,'Chat::Server']]]
];
