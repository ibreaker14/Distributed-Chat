var searchData=
[
  ['scan',['scan',['../class_chat_1_1_client.html#af144b986a5199cee00f69f8aef9e777b',1,'Chat::Client']]],
  ['server',['Server',['../class_chat_1_1_server.html',1,'Chat.Server'],['../class_chat_1_1_server.html#a3d7288f69967e91d0f3dbfb148f4270b',1,'Chat.Server.Server()']]],
  ['servsock',['servSock',['../class_chat_1_1_server.html#a60349fdcc93e1fecff4152dd85dddc88',1,'Chat::Server']]],
  ['socket',['socket',['../class_chat_1_1_client.html#aa87f388baa1816a014b46adef9fc6c03',1,'Chat::Client']]]
];
