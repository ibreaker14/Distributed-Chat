var searchData=
[
  ['jsonmessage',['JSONMessage',['../class_chat.html#aedb8547771734d3275f8acfe106ba332',1,'Chat']]]
];
